import express from 'express'
import { CreateCategoryController, UpdateCategoryController, categoryController, deleteCategoryController, singleCategoryController } from '../controllers/categoryController.js';
import { isAdmin, requireSignIn } from '../middlewares/authMiddleware.js';
const router=express.Router()

// routes 
//Create Category
router.post('/create-category',requireSignIn,isAdmin,CreateCategoryController)

//Update Category

router.put('/update-category/:id',requireSignIn,isAdmin,UpdateCategoryController)


//getAll Category

router.get('/get-category',categoryController)
export default router;


//Single Category 
router.get('/single-category/:slug',singleCategoryController)

//Delete Category
router.delete('/delete-category/:id',requireSignIn,isAdmin,deleteCategoryController)