import React, { useState } from 'react'
import Layout from '../../components/Layout/Layout'
import axios from 'axios'
import { useNavigate } from 'react-router-dom'
import { toast } from 'react-toastify'
import '../../components/styles/AuthStyles.css'
const Register = () => {
  
    const [registerData,setRegisterData]=useState({})
    const Navigate=useNavigate()
   async function handelSubmit(e){
        e.preventDefault()
      try{
        const res= await axios.post(`${process.env.REACT_APP_API}/api/v1/auth/register`,{
            ...registerData
        });
        if(res && res.data.success){
            
            toast.success(res.data.message)
            setTimeout(()=>{
            Navigate('/login')


            },3000)
        }
        else{
            toast.error(res.data.message)
        }

      }catch(err){
        console.log(err)
        toast.error('Something Went Wrong')
      }
    }

    function changeRegisterData(e){
        setRegisterData({...registerData,[e.target.name]:e.target.value}) 


    }
  return (
   

<Layout title="Register - Ecommer App">
<div className="form-container" style={{ minHeight: "70vh" }}>
  <form>
    <h4 className="title">REGISTER FORM</h4>
    <div className="mb-3">
      <input
        type="text"
        onChange={changeRegisterData}
        name='name'
        className="form-control"
        id="exampleInputName1"
        placeholder="Enter Your Name"
        required
        autoFocus
      />
    </div>
    <div className="mb-3">
      <input
        type="email"
        name='email'
        onChange={changeRegisterData}
        className="form-control"
        id="exampleInputEmail1"
        placeholder="Enter Your Email "
        required
      />
    </div>
    <div className="mb-3">
      <input
        type="password"
        name='password'
        className="form-control"
        onChange={changeRegisterData}
        id="exampleInputPassword1"
        placeholder="Enter Your Password"
        required
      />
    </div>
    <div className="mb-3">
      <input
        type="text"
        name='phone'
        onChange={changeRegisterData}
        className="form-control"
        id="exampleInputPhone1"
        placeholder="Enter Your Phone"
        required
      />
    </div>
    <div className="mb-3">
      <input
        type="text"
        name='address'
        className="form-control"
        id="exampleInputAddress1"
        onChange={changeRegisterData}

        placeholder="Enter Your Address"
        required
      />
    </div>
    <div className="mb-3">
      <input
        type="text"
        name='answer'
        onChange={changeRegisterData}
        className="form-control"
        id="exampleInputSports1"
        placeholder="What is Your Favorite sports"
        required
      />
    </div>
    <button type="submit" className="btn btn-primary"  onClick={handelSubmit}>
      REGISTER
    </button>
  </form>
</div>
</Layout>

  )
}


export default Register