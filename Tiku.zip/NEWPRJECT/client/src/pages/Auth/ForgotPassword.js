import React, { useContext, useState } from 'react'
import Layout from '../../components/Layout/Layout'
import { useNavigate } from 'react-router-dom'
import { toast } from 'react-toastify'
import axios from 'axios'



const ForgotPasssword = () => {
  const [forgotData,setForgotData]=useState({})
  const navigate=useNavigate()

 async function handelSubmit(e){
      e.preventDefault()
    try{
      const res= await axios.post(`${process.env.REACT_APP_API}/api/v1/auth/forgot-password`,{
          ...forgotData
      });
      
      if(res && res.data.success){
       
          toast.success(res.data.message)
          setTimeout(()=>{
            navigate( "/login");
        
          },3000)
      }
      

      else{
          toast.error(res.data.message)
      }

    }catch(err){
      console.log(err)
      toast.error('Something Went Wrong')
    }
  }

  function changeLoginData(e){
      setForgotData({...forgotData,[e.target.name]:e.target.value}) 


  }


  return (
    <Layout title={"Forgot Password - Ecommerce APP"}>
      <div className="form-container" style={{ minHeight: "70vh" }}>
      <form >
        <h4 className="title">RESET PASSWORD</h4>

        <div className="mb-3">
          <input
            type="email"
            autoFocus
            name='email'
           
            className="form-control"
            id="exampleInputEmail1"
            placeholder="Enter Your Email "
            onChange={changeLoginData}
            required
          />
        </div>


        <div className="mb-3">
          <input
            type="password"
            name='newPassword'

           
            className="form-control"
            id="exampleInputPassword1"
            placeholder="Enter Your New Password"
            onChange={changeLoginData}

            required
          />
        </div>
       
        <div className="mb-3">
          <input
            type="text"
            name='answer'

           
            className="form-control"
            id="exampleInputAnswer1"
            placeholder="Enter Your Favourite Sports"
            onChange={changeLoginData}

            required
          />
        </div>



      
        
       

        
        <button type="submit"  className="btn btn-primary" onClick={handelSubmit}>
          RESET
        </button>
      </form>
    </div>
    </Layout>
  );
};

export default ForgotPasssword;
