import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css';
import 'react-toastify/dist/ReactToastify.css';
import {BrowserRouter as Router,Routes,Route} from 'react-router-dom'
import HomePage from './pages/HomePage';
import AboutPage from './pages/AboutPage';
import ContactPage from './pages/ContactPage';
import Policy from './pages/Policy';
import Pagenotfound from './pages/Pagenotfound';
import Register from './pages/Auth/Register';
import Layout from './components/Layout/Layout';
import Login from './pages/Auth/Login';
import Dashboard from './pages/user/Dashboard';
import PrivateRoute from './Routes/Private';
import { AuthProvider } from './context/auth';
import ForgotPassword from './pages/Auth/ForgotPassword';
import AdminDashboard from './pages/Admin/AdminDashboard';
import AdminRoute from './Routes/AdminRoute';
import CreateCategory from './pages/Admin/CreateCategory';
import CreateProduct from './pages/Admin/CreateProduct';
import Users from './pages/Admin/Users';
import Profile from './pages/user/Profile';
import Products from './pages/Admin/Products';
import ProductDetails from './pages/ProductDetails';
import Search from './pages/Search';
import { SearchProvider } from './context/search';
import { CartProvider } from './context/cart';
import UpdateProduct from './pages/Admin/UpdateProduct';
import Categories from './pages/Categories';
import CategoryProduct from './pages/CategoryProduct';
import CartPage from './pages/CartPage';
import Orders from './pages/user/Order';
import AdminOrders from './pages/Admin/AdminOrders';

function App() {
  return (
   <>
   
   <Router>
    
    <AuthProvider>
      <SearchProvider>
        <CartProvider>
    <Routes>
      <Route path='/' element={<HomePage/>}></Route>
      <Route path="/product/:slug" element={<ProductDetails />} />
      <Route path="/categories" element={<Categories />} />
      <Route path="/category/:slug" element={<CategoryProduct />} />
      <Route path="/cart" element={<CartPage />} />


      <Route path='/search' element={<Search/>}></Route>
      
      <Route path='/dashboard' element={<PrivateRoute/>}>
      <Route path='user' element={<Dashboard/>}>
      </Route>
      <Route path='user/orders' element={<Orders/>}>
      </Route>

      <Route path='user/profile' element={<Profile/>}>
      </Route>

      </Route>


      <Route path='/dashboard' element={<AdminRoute/>}>

      <Route path='admin' element={<AdminDashboard/>}>
      </Route>
      
      <Route path='admin/create-category' element={<CreateCategory/>}>
      </Route>

      <Route path='admin/create-product' element={<CreateProduct/>}>
      </Route>
      <Route path='admin/update-product/:slug' element={<UpdateProduct/>}>
      </Route>

      <Route path='admin/Products' element={<Products/>}>
      </Route>
      <Route path='admin/users' element={<Users/>}>
      </Route>
      <Route path="admin/orders" element={<AdminOrders/>} />



      </Route>

      

      <Route path='/forgot-password' element={<ForgotPassword/>}></Route>
      
      <Route path='/register' element={<Register/>}></Route>
      <Route path='/login' element={<Login/>}></Route>
      <Route path='/about' element={<AboutPage/>}></Route>
      <Route path='/contact' element={<ContactPage/>}></Route>
      <Route path='/policy' element={<Policy/>}></Route>
      <Route path='*' element={<Pagenotfound/>}></Route>
    </Routes>
    </CartProvider>
    </SearchProvider>
    </AuthProvider>
   </Router>
   </>
  );
}

export default App;
