
export function setStorage(storageData){

    localStorage.setItem('auth',JSON.stringify(storageData))
   
}


export function getToken(){
if(localStorage.getItem('auth')){
return  JSON.parse(localStorage.getItem('auth')).token

}

else{
  return false;
}

}




export function clearStorage(){
  localStorage.clear()


}



export function getStorage(){
  if(localStorage.getItem('auth')){
      return  JSON.parse(localStorage.getItem('auth'))
      
      }
      // else{
      //     return false;
      // }
  
  }

